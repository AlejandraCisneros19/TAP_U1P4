/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.u1_practica4;

/**
 *
 * @author REAL
 */
class datos {
    float est,pes,imc;

    public datos(float est, float pes, float imc) {
        this.est = est;
        this.pes = pes;
        this.imc = imc;
    }

    public float getEst() {
        return est;
    }

    public void setEst(float est) {
        this.est = est;
    }

    public float getPes() {
        return pes;
    }

    public void setPes(float pes) {
        this.pes = pes;
    }

    public float getImc() {
        return imc;
    }

    public void setImc(float imc) {
        this.imc = imc;
    }
    
    
    
}
